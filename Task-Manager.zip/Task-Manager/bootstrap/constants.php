<?php
define("SITE_TITLE","Task Manager");
define("BASE_URL","http://127.0.0.1/Ahmad/task-manager/");
define('BASE_PATH','C:/xampp/htdocs/Ahmad/Task-Manager/');