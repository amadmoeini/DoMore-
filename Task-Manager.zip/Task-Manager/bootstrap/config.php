<?php

$database_config = (object)[
    "host" => "localhost",
    "user" => "root",
    "password" => "",
    "db" => "taskmanager",
];
