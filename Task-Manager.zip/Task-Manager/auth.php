<?php 
include "bootstrap/init.php";

$home_url =  site_url();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $action =  $_GET['action'];
    $params = $_POST;
    if ($action == 'register') {
        $result = register($params);
        if (!$result) {
            message("ERROR : an error Registation!");
        }else{
            message("Registation is successfully. Welcome to task manager <br>
            <a href='$home_url'>Manage Your task</a>
            ");
        }
    }else if($action == 'login'){
        $result = login($params['email'],$params['password']);
        if (!$result) {
            message("ERROR : an error login Data!","error");
        }else{
            message("You are in Log In. <br>
            <a href='$home_url'>Manage Your task</a>
            ");
        }
    }
}


include "views/tmp-auth.php";