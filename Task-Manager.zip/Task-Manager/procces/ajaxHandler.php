<?php
include "../bootstrap/init.php";

if (!isAjaxRequest()) {
    diePage("invalid request");
}

if (!isset($_POST["action"]) || empty($_POST["action"])) {
    diePage("invalid request");
}


switch ($_POST['action']) {
    case 'doneSwitch':
        $taskid = $_POST['tasksid'];
        if (!isset($taskid) || !is_numeric($taskid) ) {
            echo('تسک نامعتبراست !');
            die();
        }
         doneSwitch($taskid);
        break;

    case 'addFolder':
        if (!isset($_POST['folderName']) || strlen($_POST['folderName']) < 3) {
            diePage('نام Folder باید بیتشر از سه حرف باشد!');
        }
        echo addFolder($_POST['folderName']);
        break;

    case 'addTask':
        $folderid = $_POST['folderid'];
        $taskName = $_POST['taskName'];

        if (!isset($folderid) || !is_numeric($folderid) || $folderid <= 0) {
            echo ('لطفاً یک فولدر معتبر انتخاب کنید');
            die();
        }

        if (!isset($taskName) || strlen($taskName) < 3) {
            echo ('نام Task باید بشتر از 3 حرف باشد!');
            die();
        }

        echo addTask($taskName, $folderid);
        break;
    default:
        diePage('Invalid action');
        break;
}
