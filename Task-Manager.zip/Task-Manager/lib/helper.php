<?php

function diePage($msg)
{
  echo "<div class='diePage' style='  padding:30px;
  width: 80%;
  margin: 50px auto;
  background: #f9dede;
  border: 1px solid #cca4a4;
  border-radius: 5px;
  font-family: sans-serif;'>$msg</div>";
  die();
}

function message($msg , $class = 'success')
{
  echo "<div class='diePage $class' style='padding:30px;
  width: 80%;
  margin: 50px auto;
  border-radius: 5px;
  font-family: sans-serif;'>$msg</div>";
}

function dd($msg)
{
  echo "<pre style='z-index:999;position: relative; background-color: #fff; border-left: 5px solid red; width: 80%; padding: 30px; border-radius: 10px;'>";
  var_dump($msg);
  echo "</pre>";
}

function site_url($url = '')
{
  return BASE_URL . $url;
}
