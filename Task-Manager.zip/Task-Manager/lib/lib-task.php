<?php

function isAjaxRequest()
{
    if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        return true;
    }
    return false;
}

function addFolder($folder_name)
{
    global $pdo;
    $user_id = getCurrentUserId();
    $sql = "INSERT INTO folders (name,user_id) VALUES (:folder_name,:user_id)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':folder_name' => $folder_name, ':user_id' => $user_id]);
    return $stmt->rowCount();
}

function deleteFolder($folder_id)
{
    global $pdo;
    $sql = "DELETE FROM folders WHERE id = $folder_id";
    $stmt = $pdo->query($sql);
    $stmt->execute();
    return $stmt->rowCount();
}

function addTask($taskName, $folder_id)
{
    global $pdo;
    $user_id = getCurrentUserId();
    $sql = "INSERT INTO tasks (name,folder_id,user_id) VALUES (:taskName,:folder_id,:user_id)";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':taskName' => $taskName, ':folder_id' => $folder_id, ':user_id' => $user_id]);
    return $stmt->rowCount();
}

function deleteTask($task_id)
{
    global $pdo;
    $sql = "DELETE FROM tasks WHERE id = $task_id";
    $stmt = $pdo->query($sql);
    $stmt->execute();
    return $stmt->rowCount();
}

function getFolder()
{
    global $pdo;
    $user_id = getCurrentUserId();
    $sql = "SELECT * FROM folders WHERE user_id = $user_id";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $records = $stmt->fetchAll(PDO::FETCH_OBJ);

    return $records;
}

function getTasks()
{
    global $pdo;
    $folder = $_GET['folder_id'] ?? null;
    $folderCondition = '';
    if (isset($folder) && is_numeric($folder)) {
        $folderCondition = "and folder_id = $folder";
    }
    $user_id = getCurrentUserId();
    $sql = "SELECT * FROM tasks WHERE user_id = $user_id $folderCondition";
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $records = $stmt->fetchAll(PDO::FETCH_OBJ);
    return $records;
}


function doneSwitch($task_id)
{
    global $pdo;
    $user_id = getCurrentUserId();
    $sql = "UPDATE tasks SET is_done = 1 - is_done  WHERE user_id = :user_id AND id = :task_id ;";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([':user_id'=>$user_id,':task_id'=>$task_id]);
    $records = $stmt->fetchAll(PDO::FETCH_OBJ);

    return $records;
}
