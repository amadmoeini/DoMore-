<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <title>Task Management Dashboard UI</title>
  <link rel="stylesheet" href="<?= site_url('assets/css/style.css') ?>">

</head>

<body>
  <!-- partial:index.partial.html -->
  <link href="https://fonts.googleapis.com/css?family=DM+Sans:400,500,700&display=swap" rel="stylesheet">
  <div class="task-manager">
    <div class="left-bar">
      <div class="upper-part">
        <div class="actions">
          <div class="circle"></div>
          <div class="circle-2"></div>
        </div>
      </div>
      <div class="left-content">
        <ul class="action-list">
          <li class="item item-title" style="padding-left: 0px;">
            <span>Folders</span>
          </li>
          <li class="item <?= isset($_GET['folder_id']) ? ' ' : 'active'  ?>">
            <a href="<?= BASE_URL ?>">
              <i class="fa-solid fa-folder"></i>
              <span>All</span>
            </a>
          </li>
          <!-- show folders -->
          <?php foreach ($folders as $folder) : ?>
            <li class="item items <?= (isset($_GET['folder_id']) && $_GET['folder_id'] == $folder->id) ? 'active' : '' ?>" style="display: flex;justify-content: space-between;">
              <a href="?folder_id=<?= $folder->id ?>">
                <i class="fa-solid fa-folder"></i>
                <span><?= $folder->name ?></span>
              </a>
              <a href="?delete_folder=<?= $folder->id ?>" onclick="return confirm('Are you sure to Delete this itme?');">
                <i class="fa-solid fa-trash"></i>
              </a>
            </li>
          <?php endforeach; ?>
        </ul>
        <ul>
          <li style="margin-top: 10px;padding:10px;">
            <span>Add New Folders</span>
            <input type="text" name="addFolderInput" id="addFolderInput" style="width: 80%;">
            <button id="addFolderBtn" class="btn" style="border:1px solid gray;">+</button>
          </li>
        </ul>
        <div class="profile">
          <img src="<?= $user->image; ?>" alt="">
          <span><?= $user->name ?></span>
          <a href="<?= site_url('?logout=1') ?>"><i class="fa-solid fa-sign-out-alt redColor fa-2x"></i></a>
        </div>
      </div>
    </div>

    <div class="page-content">
      <div class="header">
        <div>Today Tasks</div>
        <div class="addtask" style="display: flex;flex-direction:column;">
          <span style="font-size: 15px;">Add New Task</span>
          <input type="text" name="addTaskInput" id="addTaskInput" style="width:100%;padding: 5px;
    border: 2px solid gray;
    border-radius: 4px;
    margin: 7px 0px;
    width: 100%;">
        </div>
      </div>
      <div class="content-categories">
        <div class="label-wrapper">
          <input class="nav-item" name="nav" type="radio" id="opt-1">
          <label class="category" for="opt-1">All</label>
        </div>
        <div class="label-wrapper">
          <input class="nav-item" name="nav" type="radio" id="opt-2" checked>
          <label class="category" for="opt-2">Important</label>
        </div>
        <div class="label-wrapper">
          <input class="nav-item" name="nav" type="radio" id="opt-3">
          <label class="category" for="opt-3">Notes</label>
        </div>
        <div class="label-wrapper">
          <input class="nav-item" name="nav" type="radio" id="opt-4">
          <label class="category" for="opt-4">Links</label>
        </div>
      </div>

      <div class="tasks-wrapper" id="action-list-task">
        <?php if (sizeof($tasks) > 0) : ?>
          <?php foreach ($tasks as $task): ?>
            <div class="task <?= $task->is_done ? 'checked' : ''; ?>">
              <label for="item-1">
                <i data-taskid="<?= $task->id ?>" class="isdone <?= $task->is_done ? "fa-regular fa-square-check fa-2x" : "fa-regular fa-square fa-2x"; ?>" style="margin-right:20px;"></i>
                <span class="label-text"><?= $task->name ?></span>
              </label>
              <!-- <span class="tag approved">Approved</span> -->
              <div class="left-section">
                <span>Created_at <?= $task->created_at ?></span>
                <a href="?delete_task=<?= $task->id ?>">
                  <i class="fa-solid fa-trash" onclick="return confirm('Are you sure to Delete this itme?');" style="color: rgb(196, 0, 0);margin-left:10px;"></i>
                </a>
              </div>
            </div>
          <?php endforeach; ?>
        <?php else: ?>
          <hr>
          <span class="task">No Tasks Here ...</span>
          <hr>
        <?php endif; ?>


      </div>
    </div>
  </div>

  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

  <script>
    $(document).ready(function() {
      $("#addFolderBtn").click(function(e) {
        var input = $("#addFolderInput");
        $.ajax({
          url: "procces/ajaxHandler.php",
          method: "post",
          data: {
            action: "addFolder",
            folderName: input.val()
          },
          success: function(response) {
            $('<li class="item items" style="display: flex;justify-content:space-between;"><a href=""><i class="fa-solid fa-folder"></i> <span>' + input.val() + '</span> </a></li>').appendTo('ul.action-list')
          }
        })
      });

      $('.isdone').click(function() {
        var tid = $(this).attr('data-taskid')
        $.ajax({
          url: "procces/ajaxHandler.php",
          method: "post",
          data: {
            action: "doneSwitch",
            tasksid: tid,
          },
          success: function(response) {
            location.reload();
          }
        })

      });

      $("#addTaskInput").on('keypress', function(e) {
        e.stopPropagation();
        if (e.which == 13) {
          $.ajax({
            url: "procces/ajaxHandler.php",
            method: "post",
            data: {
              action: "addTask",
              taskName: $("#addTaskInput").val(),
              folderid: <?= $_GET['folder_id'] ?? 0; ?>,
            },
            success: function(response) {
              if (response == '1') {
                location.reload();
              } else {
                alert(response);
              }
            }
          })
        };
      });
      $("#addTaskInput").focus();
    });
  </script>
</body>

</html>