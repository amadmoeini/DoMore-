<?php 
include "bootstrap/init.php";

function logout(){
    unset($_SESSION['login']);    
}

if (isset($_GET['logout'])) {
    logout();
}

if(!isLoggedIn()){
    header("location: ". site_url("auth.php"));
}

$user = getLoggedInUser();

if (isset($_GET["delete_folder"]) && is_numeric($_GET["delete_folder"])) {
    deleteFolder($_GET["delete_folder"]);
    // echo "$deleteCount was deleted";
}

if (isset($_GET["delete_task"]) && is_numeric($_GET["delete_task"])) {
    deleteTask($_GET["delete_task"]);
    // echo "$deleteCount was deleted";
}

$folders = getFolder();
$tasks = getTasks();
// dd($tasks);

include "views/tmp-index.php";